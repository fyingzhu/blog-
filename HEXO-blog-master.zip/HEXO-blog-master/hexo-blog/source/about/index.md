---
title: about
date: 2017-06-14 22:15:08
---

你好，这是孤鸿的家．
正处于齐一所说的[这个年纪](http://music.163.com/#/song?id=35476049) (ps:很想插入这首音乐无奈版权)

笔者已经大二,一事无成.
前面搞过ACM,[我有关ACM的blog](http://write.blog.csdn.net/postlist),现在准备改行了(牌都没拿就要退役了)，想去追求自己的初心，曾经入门计算机这个专业本就是想着，能让更多的人从体力劳动中解脱出来.听说现在已经由很多人在干这个事了,无人驾驶,IBM　watson 的医疗诊断,google的机器翻译......每一项人工智能的杰作似乎都在告诉我们未来已经来啦.

这个blog主要是记录个人的生活点滴，以及个人学习机器学习的那些事

互联网是个很平等的地方，只要你想学总能找到自己要学的
<iframe frameborder="no" border="0" marginwidth="0" marginheight="0" width=330 height=86 src="//music.163.com/outchain/player?type=2&id=41664790&auto=1&height=66"></iframe>
