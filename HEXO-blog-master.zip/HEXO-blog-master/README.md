# HEXO-blog
这是我hexo博客的所有配置文件,避免每次还电脑遗失，特备份主题是next
